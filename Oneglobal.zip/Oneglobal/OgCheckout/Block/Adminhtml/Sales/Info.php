<?php
/**
 * Copyright © 2020 Oneglobal. All rights reserved.
 */

namespace Oneglobal\OgCheckout\Block\Adminhtml\Sales;

use Oneglobal\OgCheckout\Model\Ogpay;

/**
 * Class Info
 * @package Oneglobal\OgCheckout\Block\Adminhtml\Sales
 */
class Info extends \Magento\Sales\Block\Adminhtml\Order\AbstractOrder
{
    public function canShow()
    {
        $payment = $this->getOrder()->getPayment();
        $method = $payment->getMethodInstance()->getCode();
        return $method == Ogpay::CODE;
    }
}
