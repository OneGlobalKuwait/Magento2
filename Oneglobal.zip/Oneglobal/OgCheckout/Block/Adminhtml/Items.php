<?php
/**
 * Copyright © 2020 Oneglobal. All rights reserved.
 */
namespace Oneglobal\OgCheckout\Block\Adminhtml;

/**
 * Class Items
 * @package Oneglobal\OgCheckout\Block\Adminhtml
 */
class Items extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_controller = 'items';
        $this->_headerText = __('Payment Methods');
        $this->_addButtonLabel = __('Add New Payment Methods');
        parent::_construct();
    }
}
