<?php
/**
 * Created by PhpStorm.
 * User: deepak.shinde@wearefmg.net
 * Date: 30/8/20
 * Time: 10:00 PM
 */

namespace Oneglobal\OgCheckout\Block\Adminhtml\Form\Field;

use Magento\Framework\View\Element\AbstractBlock;
use Magento\Config\Model\Config\CommentInterface;

/**
 * Class CustomizeMethodsUrl
 * @package Oneglobal\OgCheckout\Block\Adminhtml\Form\Field
 */
class CustomizeMethodsUrl extends AbstractBlock implements CommentInterface
{
    public function getCommentText($elementValue)
    {
        $url = $this->getUrl('oneglobal_ogcheckout/items/index');
        return "Save current configuration and <a href='$url' target='_blank'>Add new Payment Methods</a>";
    }
}
