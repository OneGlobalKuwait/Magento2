<?php
/**
 * Copyright © 2020 Oneglobal. All rights reserved.
 */

namespace Oneglobal\OgCheckout\Controller\Adminhtml\Items;

/**
 * Class Save
 * @package Oneglobal\OgCheckout\Controller\Adminhtml\Items
 */
class Save extends \Oneglobal\OgCheckout\Controller\Adminhtml\Items
{
    public function execute()
    {
        if ($this->getRequest()->getPostValue()) {
            try {
                $model = $this->_objectManager->create('Oneglobal\OgCheckout\Model\Items');
                $data = $this->getRequest()->getPostValue();
                $inputFilter = new \Zend_Filter_Input(
                    [],
                    [],
                    $data
                );
                $data = $inputFilter->getUnescaped();
                $data['currency_code'] = strtoupper(trim($data['currency_code']));
                $id = $this->getRequest()->getParam('id');
                if ($id) {
                    $model->load($id);
                    if ($id != $model->getId()) {
                        throw new \Magento\Framework\Exception\LocalizedException(__('The wrong method is specified.'));
                    }
                }
                $model->setData($data);
                $session = $this->_objectManager->get('Magento\Backend\Model\Session');
                $session->setPageData($model->getData());
                $model->save();
                $this->messageManager->addSuccess(__('You saved the method.'));
                $session->setPageData(false);
                if ($this->getRequest()->getParam('back')) {
                    $this->_redirect('oneglobal_ogcheckout/*/edit', ['id' => $model->getId()]);
                    return;
                }
                $this->_redirect('oneglobal_ogcheckout/*/');
                return;
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
                $id = (int)$this->getRequest()->getParam('id');
                if (!empty($id)) {
                    $this->_redirect('oneglobal_ogcheckout/*/edit', ['id' => $id]);
                } else {
                    $this->_redirect('oneglobal_ogcheckout/*/new');
                }
                return;
            } catch (\Exception $e) {
                $this->messageManager->addError(
                    __('Something went wrong while saving the method data. Please review the error log.')
                );
                $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
                $this->_objectManager->get('Magento\Backend\Model\Session')->setPageData($data);
                $this->_redirect('oneglobal_ogcheckout/*/edit', ['id' => $this->getRequest()->getParam('id')]);
                return;
            }
        }
        $this->_redirect('oneglobal_ogcheckout/*/');
    }
}
