<?php
/**
 * Copyright © 2020 Oneglobal. All rights reserved.
 */

namespace Oneglobal\OgCheckout\Controller\Adminhtml\Items;

/**
 * Class NewAction
 * @package Oneglobal\OgCheckout\Controller\Adminhtml\Items
 */
class NewAction extends \Oneglobal\OgCheckout\Controller\Adminhtml\Items
{

    public function execute()
    {
        $this->_forward('edit');
    }
}
