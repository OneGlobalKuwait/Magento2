<?php
/**
 * Copyright © 2020 Oneglobal. All rights reserved.
 */

namespace Oneglobal\OgCheckout\Controller\Adminhtml\Items;

/**
 * Class Index
 * @package Oneglobal\OgCheckout\Controller\Adminhtml\Items
 */
class Index extends \Oneglobal\OgCheckout\Controller\Adminhtml\Items
{
    /**
     * Items list.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Oneglobal_Ogpay::ogpay');
        $resultPage->getConfig()->getTitle()->prepend(__('Og Checkout Payment Methods'));
        $resultPage->addBreadcrumb(__('Oneglobal'), __('Oneglobal'));
        $resultPage->addBreadcrumb(__('Payment Methods'), __('Payment Methods'));
        return $resultPage;
    }
}
