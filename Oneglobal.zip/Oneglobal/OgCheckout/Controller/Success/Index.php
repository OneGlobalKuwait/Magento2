<?php
/**
 * Created by PhpStorm.
 * User: deepak.shinde@wearefmg.net
 * Date: 19/8/20
 * Time: 9:49 PM
 */

namespace Oneglobal\OgCheckout\Controller\Success;

use Magento\Checkout\Model\Session;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Exception\LocalizedException;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Payment\Transaction;
use Oneglobal\OgCheckout\Model\ProcessResult;
use Magento\Sales\Model\Service\InvoiceService;
use Magento\Framework\Serialize\Serializer\Json;

/**
 * Class Index
 * @package Oneglobal\OgCheckout\Controller\Success
 */
class Index extends Action
{
    const PATH_CART  = 'checkout/cart';

    const PATH_SUCCESS = 'checkout/onepage/success';

    /**
     * @var InvoiceService
     */
    private $_invoiceService;

    private $json;

    /**
     * Index constructor.
     * @param Context $context
     * @param Session $session
     * @param Json $json
     * @param Order $order
     * @param InvoiceService $invoiceService
     * @param ProcessResult $processResult
     */
    public function __construct(
        Context $context,
        Session $session,
        Json $json,
        Order $order,
        InvoiceService $invoiceService,
        ProcessResult $processResult
    ) {
        $this->session = $session;
        $this->processResult = $processResult;
        $this->_invoiceService = $invoiceService;
        $this->json = $json;
        $this->order = $order;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface
     * @throws LocalizedException
     */
    public function execute()
    {
        //$order = $this->session->getLastRealOrder();
        $params = $this->getRequest()->getParams();

        $orderId = $this->getRequest()->getParam('orderid');

        if (!$orderId) {
            $this->messageManager->addErrorMessage(__('Cannot retrieve a order detail from the request. Please contact our support if you have any questions.'));

            return $this->redirect(self::PATH_CART);
        }

        $order = $this->getOrder($params['orderid']);

        if (!$order->getId()) {
            $this->messageManager->addErrorMessage(__('The order session no longer exists, please make an order again or contact our support if you have any questions.'));

            return $this->redirect(self::PATH_CART);
        }

        $valid = $this->processResult->validResponse($params);

        if (!$valid) {
            $this->messageManager->addErrorMessage(__('Cannot validate the payment. Please contact our support if you have any questions.'));
            return $this->redirect(self::PATH_CART);
        }

        if ($order->getState() === Order::STATE_PROCESSING) {
            return $this->redirect(self::PATH_SUCCESS);
        }

        if ($order->getState() !== Order::STATE_PENDING_PAYMENT) {
            $this->invalid($order, __('Invalid order status, cannot validate the payment. Please contact our support if you have any questions.'));

            return $this->redirect(self::PATH_CART);
        }

        if (!$payment = $order->getPayment()) {
            $this->invalid($order, __('Cannot retrieve a payment detail from the request. Please contact our support if you have any questions.'));

            return $this->redirect(self::PATH_CART);
        }

        $transId = $params['trackid'];
        if (!array_key_exists('refid', $params) || !empty($params['refid'])) {
            $transId = $params['refid'];
        }

        try {

            $trackid = !empty($params['trackid']) ? $params['trackid'] : 'NA';
            $refid = !empty($params['refid']) ? $params['refid'] : 'NA';

            if ($params['result'] != 'CAPTURED') {
                $message = __(
                    'Payment failed. %1, please contact our support if you have any questions. Track ID: %2 and Reference ID: %3',
                    ucfirst($params['result']),
                    $trackid,
                    $refid
                );
                $this->processResult->addCommentToStatusHistory($order, $message);

                throw new LocalizedException($message);
            }

            $payment->setTransactionId($transId);
            $payment->setLastTransId($transId);
            $payment->setAdditionalData($this->json->serialize($params));

            if ($params['result'] == 'CAPTURED') {
                // Update order state and status.
                $order->setState(Order::STATE_PROCESSING);
                $order->setStatus($order->getConfig()->getStateDefaultStatus(Order::STATE_PROCESSING));

                $invoice = $this->invoice($order);
                $invoice->setTransactionId($transId)->pay()->save();

                /**
                 * Add order history comment
                 */
                $this->processResult->addCommentToStatusHistory(
                    $order,
                    __(
                        "Amount of %1 has been paid via Og Checkout payment. Track ID: %2 and Reference ID: %3",
                        $order->getBaseCurrency()->formatTxt($invoice->getBaseGrandTotal()),
                        $trackid,
                        $refid
                    )
                );

                $order->save();
                return $this->redirect(self::PATH_SUCCESS);
            }

            // Update order state and status.
            $order->setState(Order::STATE_PAYMENT_REVIEW);
            $order->setStatus($order->getConfig()->getStateDefaultStatus(Order::STATE_PAYMENT_REVIEW));

            // Add transaction.
            $transaction = $payment->addTransaction(Transaction::TYPE_PAYMENT);
            $transaction->setIsClosed(false);
            $payment->addTransactionCommentsToOrder(
                $transaction,
                __('The payment has been processing.<br/>Due to the Bank process, this might takes a few seconds or up-to an hour. Please click "Accept" or "Deny" the payment manually once the result has been updated (you can check at Ogpay Dashboard).')
            );

            $order->save();

            return $this->redirect(self::PATH_SUCCESS);
        } catch (\Exception $e) {
            $this->cancel($order, $e->getMessage());
            $payment->setTransactionId($transId);
            $payment->setLastTransId($transId);
            $payment->setAdditionalData($this->json->serialize($params));
            $order->save();

            return $this->redirect(self::PATH_CART);
        }
    }

    /**
     * @param  string $path
     *
     * @return \Magento\Framework\App\ResponseInterface
     */
    protected function redirect($path)
    {
        return $this->_redirect($path, ['_secure' => true]);
    }

    /**
     * @param Order $order
     * @return Order\Invoice
     * @throws LocalizedException
     */
    protected function invoice(Order $order)
    {
        $invoice = $this->_invoiceService->prepareInvoice($order);
        $invoice->setRequestedCaptureCase(\Magento\Sales\Model\Order\Invoice::CAPTURE_OFFLINE);
        return $invoice->register();
    }

    /**
     * @param Order $order
     * @param $message
     * @throws LocalizedException
     */
    protected function cancel(Order $order, $message)
    {
        $order->registerCancellation()->save();
        $this->messageManager->addErrorMessage($message);
    }

    /**
     * @param $incrementId
     * @return Order
     */
    protected function getOrder($incrementId)
    {
        try {
            return $this->order->loadByIncrementId($incrementId);
        } catch (\LogicException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        }
    }
}
