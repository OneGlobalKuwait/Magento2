<?php
/**
 * Created by PhpStorm.
 * User: deepak.shinde@wearefmg.net
 * Date: 18/8/20
 * Time: 11:31 PM
 */

namespace Oneglobal\OgCheckout\Controller\Redirect;

use Magento\Framework\App\Action\Action;
use Magento\Framework\Controller\ResultFactory;

/**
 * Class Index
 * @package Oneglobal\OgCheckout\Controller\Redirect
 */
class Index extends Action
{
    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $_checkoutSession;

    /**
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected $_orderFactory;

    /**
     * Index constructor.
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Sales\Model\OrderFactory $orderFactory
    ) {
        $this->_checkoutSession = $checkoutSession;
        $this->_orderFactory = $orderFactory;
        return parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {		
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);

        $resultRedirect->setUrl($this->getPaymentRedirectUrl());
        return $resultRedirect;
    }

    /**
     * @return mixed
     */
    private function getRealOrderId()
    {
        $lastorderId = $this->_checkoutSession->getLastOrderId();
        return $lastorderId;
    }

    /**
     * @return bool|\Magento\Sales\Model\Order
     */
    private function getOrder()
    {
        if ($this->_checkoutSession->getLastRealOrderId()) {
            $order = $this->_orderFactory->create()->loadByIncrementId(
                $this->_checkoutSession->getLastRealOrderId()
            );
            return $order;
        }
        return false;
    }

    /**
     * @return bool|string[]
     */
    private function getPaymentRedirectUrl()
    {
        $order = $this->getOrder();
		
        if ($order) {
            $payment = $order->getPayment();
            $paymentRedirectUrl = $payment->getAdditionalInformation('payment_redirect_url');

            return $paymentRedirectUrl;
        }

        return false;
    }
}
