<?php

namespace Oneglobal\OgCheckout\Api\Data;

/**
 * Interface RequestInterface
 * @package Oneglobal\OgCheckout\Api\Data
 */
interface RequestInterface
{
    /**
     * @return mixed
     */
    public function getMerchantCode();

    /**
     * @param $merchantCode
     * @return mixed
     */
    public function setMerchantCode($merchantCode);

    /**
     * @return mixed
     */
    public function getAuthKey();

    /**
     * @param $authKey
     * @return mixed
     */
    public function setAuthKey($authKey);

    /**
     * @return mixed
     */
    public function getSecretKey();

    /**
     * @param $secretKey
     * @return mixed
     */
    public function setSecretKey($secretKey);

    /**
     * @return mixed
     */
    public function getCurrency();

    /**
     * @param $currency
     * @return mixed
     */
    public function setCurrency($currency);

    /**
     * @param $paymentChannel
     * @return mixed
     */
    public function setPaymentChannel($paymentChannel);

    /**
     * @return mixed
     */
    public function getPaymentChannel();

    /**
     * @return mixed
     */
    public function getTunnel();

    /**
     * @param $tunnel
     * @return mixed
     */
    public function setTunnel($tunnel);

    /**
     * @return mixed
     */
    public function getAmount();

    /**
     * @param $amount
     * @return mixed
     */
    public function setAmount($amount);

    /**
     * @param $doConvert
     * @return mixed
     */
    public function setDoConvert($doConvert);

    /**
     * @return mixed
     */
    public function getDoConvert();

    /**
     * @return mixed
     */
    public function getSourceCurrency();

    /**
     * @param $sourceCurrency
     * @return mixed
     */
    public function setSourceCurrency($sourceCurrency);

    /**
     * @return mixed
     */
    public function getDescription();

    /**
     * @param $description
     * @return mixed
     */
    public function setDescription($description);

    /**
     * @return int
     */
    public function getReferenceID();

    /**
     * @param int $referenceId
     * @return mixed
     */
    public function setReferenceID($referenceId);

    /**
     * @return mixed
     */
    public function getTimeStamp();

    /**
     * @param $timeStamp
     * @return mixed
     */
    public function setTimeStamp($timeStamp);

    /**
     * @return mixed
     */
    public function getLanguage();

    /**
     * @param $language
     * @return mixed
     */
    public function setLanguage($language);

    /**
     * @return mixed
     */
    public function getCallbackURL();

    /**
     * @param $callbackURL
     * @return mixed
     */
    public function setCallbackURL($callbackURL);

    /**
     * @return mixed
     */
    public function getHash();

    /**
     * @param $hash
     * @return mixed
     */
    public function setHash($hash);

    /**
     * @return mixed
     */
    public function getUserReference();

    /**
     * @param $userReference
     * @return mixed
     */
    public function setUserReference($userReference);
}
