/* @api */
define(['ko'], function (ko) {
    'use strict';

    return {
        paymentChannel:ko.observableArray([]),
        creditCardNumber: null,
        expirationMonth: null,
        expirationYear: null,
        cvvCode: null
    };
});