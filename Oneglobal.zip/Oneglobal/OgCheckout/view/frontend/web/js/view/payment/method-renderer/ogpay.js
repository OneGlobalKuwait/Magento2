define([
        'jquery',
        'Magento_Checkout/js/view/payment/default',
        'Oneglobal_OgCheckout/js/model/ogpay-data',
        'Oneglobal_OgCheckout/js/action/set-payment-method-action',
        'Magento_Checkout/js/model/payment/additional-validators',
        'ko'
    ],
    function ($, Component, OgpayData, setPaymentMethodAction, additionalValidators, ko) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'Oneglobal_OgCheckout/payment/ogpay'
            },
            redirectAfterPlaceOrder: false,

            /**
             * After place order callback
             */
            afterPlaceOrder: function () {
                setPaymentMethodAction(this.messageContainer);
                return false;
            },
            /**
             * Initiate observable fields
             *
             * @return this
             */
            initObservable: function() {
                this._super()
                    .observe([
                        'paymentChannel'
                    ]);

                return this;
            },

            initialize: function() {
                var self = this;
                this._super();

                //Set expiration year to credit card data object
                this.paymentChannel.subscribe(function(value) {
                    OgpayData.paymentChannel = value;
                });
            },

            getData: function() {
                return {
                    'method': this.item.method,
                    'additional_data': {
                        'payment_channel': this.getChannel()
                    }
                };
            },

            getChannel: function() {

                if (!this.isCustomize()){
                    return window.checkoutConfig.payment.oneglobal_ogcheckout.ogpay_channel;
                }

                var channelValue = $("input[name='payment[oneglobal_ogcheckout][channel]']:checked"). val();
                if ((channelValue != null) && (channelValue.length > 0)) {
                    return channelValue;
                }
            },

            context: function() {
                return this;
            },

            getCode: function() {
                return 'oneglobal_ogcheckout';
            },

            getDescription: function() {
                return window.checkoutConfig.payment.oneglobal_ogcheckout.description;
            },

            isActive: function() {
                return true;
            },
            
            getPaymentChannelValues: function () {
                return _.map(this.getPaymentChannels(), function (value, key) {
                    return {
                        'value': key,
                        'label': value
                    };
                });
            },
            /**
             * Get list of available payment channels
             * @returns {Object}
             */
            getPaymentChannels: function () {
                return window.checkoutConfig.payment.oneglobal_ogcheckout.payment_channel;
            },
            isCustomize: function () {
                return window.checkoutConfig.payment.oneglobal_ogcheckout.is_customize;
            }
        });
    }
);
