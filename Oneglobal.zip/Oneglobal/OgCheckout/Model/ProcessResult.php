<?php
/**
 * Created by PhpStorm.
 * User: deepak.shinde@wearefmg.net
 * Date: 19/8/20
 * Time: 9:54 PM
 */

namespace Oneglobal\OgCheckout\Model;

use Oneglobal\OgCheckout\Model\OgpayConfig;

/**
 * Class ProcessResult
 * @package Oneglobal\OgCheckout\Model
 */
class ProcessResult
{
    /**
     * @var \Oneglobal\OgCheckout\Model\OgpayConfig
     */
    protected $ogpayConfig;

    /**
     * ProcessResult constructor.
     * @param \Oneglobal\OgCheckout\Model\OgpayConfig $ogpayConfig
     */
    public function __construct(
        OgpayConfig $ogpayConfig
    ) {
        $this->ogpayConfig = $ogpayConfig;
    }

    /**
     * @param array $params
     * @return bool
     */
    public function validResponse(array $params)
    {
        $datatocomputeHash = "trackid="
            . $params['trackid']
            . "&result="
            . $params['result']
            . "&refid=" . $params['refid'];
        /*if ($params['Hash'] != $this->getHashValue($datatocomputeHash)) {
            return true;
        }*/

        return true;
    }

    /**
     * @param $data
     * @return string
     */
    private function getHashValue($data)
    {
        $HashKey = $this->ogpayConfig->getSecretKey();
        $computedHash = strtoupper(hash_hmac("sha256", $data, $HashKey));

        return $computedHash;
    }

    public function addCommentToStatusHistory($order, $comment)
    {
        $history = $order->addCommentToStatusHistory($comment);
        $history->setIsVisibleOnFront(true);
        $history->setIsCustomerNotified(false);
        $history->save();
    }
}
