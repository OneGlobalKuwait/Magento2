<?php
/**
 * Copyright © 2020 Oneglobal. All rights reserved.
 */

namespace Oneglobal\OgCheckout\Model;

use Magento\Directory\Helper\Data as DirectoryHelper;
use Magento\Framework\Exception\LocalizedException;
use Magento\Payment\Gateway\Http\ClientException;
use Magento\Quote\Api\Data\PaymentInterface;
use Magento\Framework\DataObject;
use Oneglobal\OgCheckout\Model\ProcessRequest;
use Magento\Framework\HTTP\Client\Curl;
use Magento\Framework\Serialize\Serializer\Json;
use Psr\Log\LoggerInterface;
use Magento\Sales\Model\Order;

/**
 * Class Ogpay
 * @package Oneglobal\OgCheckout\Model
 * @SuppressWarnings(PHPMD.TooManyFields)
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Ogpay extends \Magento\Payment\Model\Method\AbstractMethod
{
    const CODE = 'oneglobal_ogcheckout';

    protected $_code = self::CODE;

    protected $_canAuthorize = false;

    protected $_canCapture = false;

    /**
     * Payment Method feature
     *
     * @var bool
     */
    protected $_isInitializeNeeded = true;

    /**
     * @var \Oneglobal\Ogpay\Model\ProcessRequest
     */
    protected $processRequest;

    /**
     * @var Curl
     */
    protected $curl;

    /**
     * @var Json
     */
    protected $json;

    /**
     * @var LoggerInterface
     */
    protected $loggers;

    const TOKEN_URL = '';

    /**
     * Ogpay constructor.
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory
     * @param \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory
     * @param \Magento\Payment\Helper\Data $paymentData
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Payment\Model\Method\Logger $logger
     * @param \Oneglobal\Ogpay\Model\ProcessRequest $processRequest
     * @param Curl $curl
     * @param Json $json
     * @param LoggerInterface $loggers
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource|null $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb|null $resourceCollection
     * @param array $data
     * @param DirectoryHelper|null $directory
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
        \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
        \Magento\Payment\Helper\Data $paymentData,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Payment\Model\Method\Logger $logger,
        ProcessRequest $processRequest,
        Curl $curl,
        Json $json,
        LoggerInterface $loggers,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = [],
        DirectoryHelper $directory = null
    ) {
        $this->processRequest = $processRequest;
        $this->curl = $curl;
        $this->json = $json;
        $this->loggers = $loggers;
        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $logger,
            $resource,
            $resourceCollection,
            $data,
            $directory
        );
    }

    /**
     * @param string $paymentAction
     * @param object $stateObject
     * @return \Magento\Payment\Model\Method\AbstractMethod|void
     * @throws LocalizedException
     */
    public function initialize($paymentAction, $stateObject)
    {
        try {
            $payment = $this->getInfoInstance();

            $payment_channel = '';
            if ($payment->hasAdditionalInformation('payment_channel')) {
                $payment_channel = $payment->getAdditionalInformation('payment_channel');
            }

            $order = $payment->getOrder();
            $payment->setAmountAuthorized($order->getTotalDue());
            $payment->setBaseAmountAuthorized($order->getBaseTotalDue());

            ///build array of payment data for API request.
            $request = $this->processRequest->prepareRequest(
                $payment_channel,
                $order->getTotalDue(),
                $order
            );

            $this->loggers->error('', $order->getData());

            $referenceID = $request['referenceID'];

            //serialize data
            $request = $this->json->serialize($request);

            $this->loggers->error('', [$request ]);

            //check if payment has been authorized
            $response = $this->makeAuthRequest($request);

            $payment->setAdditionalInformation(
                'payment_redirect_url',
                $response['result']['redirectURL']
            );

            if (isset($response['result']['trackID'])) {
                $payment->setTransactionId($response['result']['trackID']);
                $payment->setParentTransactionId($response['result']['trackID']);
                $payment->setLastTransId($referenceID);

                $stateObject->setState(Order::STATE_PENDING_PAYMENT);
                $stateObject->setStatus(Order::STATE_PENDING_PAYMENT);
            }

            //processing is not done yet.
            $payment->setIsTransactionClosed(0);
        } catch (\Exception $e) {
            $this->loggers->error($e->getMessage(), $payment->getData());
            throw new LocalizedException(
                __("The payment couldn't be processed at this time. Please try again later.")
            );
        }
    }

    public function isInitializeNeeded()
    {
        return true;
    }

    /**
     * Set the payment action to order
     *
     * @return string
     */
    public function getConfigPaymentAction()
    {
        return self::ACTION_ORDER;
    }

    /**
     * @param $request
     * @return array|bool|float|int|mixed|string|null
     * @throws LocalizedException
     */
    public function makeAuthRequest($request)
    {
        try {
            $this->curl->addHeader("Content-Type", "application/json");
            $this->curl->setOption(CURLOPT_SSL_VERIFYHOST, false);
            $this->curl->setOption(CURLOPT_SSL_VERIFYPEER, false);

            $url = $this->processRequest->gatewayUrl() . self::TOKEN_URL;

            $this->curl->post(
                $url,
                $request
            );

            $response = $this->curl->getBody();
            $response = $this->json->unserialize($response);
			
        } catch (LocalizedException $e) {
            $this->debug($request, $e->getMessage());
        }

        if (array_key_exists('errorCode', $response) && $response['errorCode']) {
            $this->loggers->error('Failed capture request.', $response);
            throw new ClientException(__('Failed capture request.'));
        }

        return $response;
    }

    /**
     * @param DataObject $data
     * @return $this|\Magento\Payment\Model\Method\AbstractMethod
     * @throws LocalizedException
     */
    public function assignData(\Magento\Framework\DataObject $data)
    {
        $additionalData = $data->getData(PaymentInterface::KEY_ADDITIONAL_DATA);

        if (!is_object($additionalData)) {
            $additionalData = new DataObject($additionalData ?: []);
        }

        /** @var DataObject $info */
        $info = $this->getInfoInstance();
        $info->setAdditionalInformation('payment_channel', $additionalData->getPaymentChannel());

        return $this;
    }
}
