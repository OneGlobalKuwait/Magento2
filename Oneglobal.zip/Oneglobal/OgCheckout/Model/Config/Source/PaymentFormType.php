<?php
/**
 * Created by PhpStorm.
 * User: deepak.shinde@wearefmg.net
 * Date: 10/8/20
 * Time: 11:02 PM
 */

namespace Oneglobal\OgCheckout\Model\Config\Source;

/**
 * Class PaymentFormType
 * @package Oneglobal\OgCheckout\Model\Config\Source
 */
class PaymentFormType implements \Magento\Framework\Option\ArrayInterface
{
    const CUSTOMIZE = 'customize';

    const OGPAY = 'ogpay';

    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => self::CUSTOMIZE,
                'label' => __('Customize your payment form')
            ],
            [
                'value' => self::OGPAY,
                'label' => __('Og Checkout Payment Form')
            ]
        ];
    }

    /**
     * @return array
     */
    public function toArray()
    {
        return [
            self::CUSTOMIZE => __('Customize your payment form'),
            self::OGPAY => __('Og Checkout Payment Form')
        ];
    }
}
