<?php
/**
 * Created by PhpStorm.
 * User: deepak.shinde@wearefmg.net
 * Date: 17/8/20
 * Time: 9:48 PM
 */

namespace Oneglobal\OgCheckout\Model;

use Oneglobal\OgCheckout\Api\Data\RequestInterface;
use Magento\Framework\DataObject;

/**
 * Class Request
 * @package Oneglobal\OgCheckout\Model
 */
class Request extends DataObject implements RequestInterface
{
    /**
     * @return mixed
     */
    public function getMerchantCode()
    {
        return $this->getData('merchantCode');
    }

    /**
     * @param $merchantCode
     * @return mixed|Request
     */
    public function setMerchantCode($merchantCode)
    {
        return $this->setData('merchantCode', $merchantCode);
    }

    /**
     * @return mixed
     */
    public function getAuthKey()
    {
        return $this->getData('authKey');
    }

    /**
     * @param $authKey
     * @return mixed|Request
     */
    public function setAuthKey($authKey)
    {
        return $this->setData('authKey', $authKey);
    }

    /**
     * @return mixed
     */
    public function getSecretKey()
    {
        return $this->getData('secretKey');
    }

    /**
     * @param $secretKey
     * @return mixed
     */
    public function setSecretKey($secretKey)
    {
        return $this->setData('secretKey', $secretKey);
    }

    /**
     * @return mixed
     */
    public function getCurrency()
    {
        return $this->getData('currency');
    }

    /**
     * @param $currency
     * @return mixed|Request
     */
    public function setCurrency($currency)
    {
        return $this->setData('currency', $currency);
    }

    /**
     * @return mixed
     */
    public function getPaymentChannel()
    {
        return $this->getData('paymentChannel');
    }

    /**
     * @param $paymentChannel
     * @return mixed|Request
     */
    public function setPaymentChannel($paymentChannel)
    {
        return $this->setData('paymentChannel', $paymentChannel);
    }

    /**
     * @return mixed
     */
    public function getTunnel()
    {
        return $this->getData('tunnel');
    }

    /**
     * @param $tunnel
     * @return mixed|Request
     */
    public function setTunnel($tunnel)
    {
        return $this->setData('tunnel', $tunnel);
    }

    /**
     * @return mixed
     */
    public function getAmount()
    {
        return $this->getData('amount');
    }

    /**
     * @param $amount
     * @return mixed|Request
     */
    public function setAmount($amount)
    {
        return $this->setData('amount', $amount);
    }

    /**
     * @param $doConvert
     * @return mixed
     */
    public function setDoConvert($doConvert)
    {
        return $this->setData('doConvert', $doConvert);
    }

    /**
     * @return mixed
     */
    public function getDoConvert()
    {
        return $this->getData('doConvert');
    }

    /**
     * @return mixed
     */
    public function getSourceCurrency()
    {
        return $this->getData('sourceCurrency');
    }

    /**
     * @param $sourceCurrency
     * @return mixed
     */
    public function setSourceCurrency($sourceCurrency)
    {
        return $this->setData('sourceCurrency', $sourceCurrency);
    }

    /**
     * @return mixed
     */
    public function getDescription()
    {
        return $this->getData('description');
    }

    /**
     * @param $description
     * @return mixed
     */
    public function setDescription($description)
    {
        return $this->setData('description', $description);
    }

    /**
     * @return mixed
     */
    public function getReferenceID()
    {
        return $this->getData('referenceID');
    }

    /**
     * @param $referenceId
     * @return mixed|Request
     */
    public function setReferenceID($referenceId)
    {
        return $this->setData('referenceID', $referenceId);
    }

    /**
     * @return mixed
     */
    public function getTimeStamp()
    {
        return $this->getData('timeStamp');
    }

    /**
     * @param $timeStamp
     * @return mixed
     */
    public function setTimeStamp($timeStamp)
    {
        return $this->setData('timeStamp', $timeStamp);
    }

    /**
     * @return mixed
     */
    public function getLanguage()
    {
        return $this->getData('language');
    }

    /**
     * @param $language
     * @return mixed
     */
    public function setLanguage($language)
    {
        return $this->setData('language', $language);
    }

    /**
     * @return mixed
     */
    public function getCallbackURL()
    {
        return $this->getData('callbackURL');
    }

    /**
     * @param $callbackURL
     * @return mixed
     */
    public function setCallbackURL($callbackURL)
    {
        return $this->setData('callbackURL', $callbackURL);
    }

    /**
     * @return mixed
     */
    public function getHash()
    {
        return $this->getData('hash');
    }

    /**
     * @param $hash
     * @return mixed
     */
    public function setHash($hash)
    {
        return $this->setData('hash', $hash);
    }

    /**
     * @return mixed
     */
    public function getUserReference()
    {
        return $this->getData('userReference');
    }

    /**
     * @param $userReference
     * @return mixed
     */
    public function setUserReference($userReference)
    {
        return $this->setData('userReference', $userReference);
    }
}
