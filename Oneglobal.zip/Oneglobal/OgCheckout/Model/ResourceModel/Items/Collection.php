<?php
/**
 * Copyright © 2020 Oneglobal. All rights reserved.
 */

namespace Oneglobal\OgCheckout\Model\ResourceModel\Items;

/**
 * Class Collection
 * @package Oneglobal\OgCheckout\Model\Resource\Items
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Oneglobal\OgCheckout\Model\Items', 'Oneglobal\OgCheckout\Model\ResourceModel\Items');
    }
}
