<?php
/**
 * Copyright © 2020 Oneglobal. All rights reserved.
 */

namespace Oneglobal\OgCheckout\Model\ResourceModel;

/**
 * Class Items
 * @package Oneglobal\OgCheckout\Model\Resource
 */
class Items extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Model Initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('ogcheckout_payment_methods', 'id');
    }
}
