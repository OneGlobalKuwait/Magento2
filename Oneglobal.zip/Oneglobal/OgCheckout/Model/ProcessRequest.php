<?php
/**
 * Created by PhpStorm.
 * User: deepak.shinde@wearefmg.net
 * Date: 14/8/20
 * Time: 11:58 PM
 */

namespace Oneglobal\OgCheckout\Model;

use Oneglobal\OgCheckout\Model\OgpayConfig;
use Oneglobal\OgCheckout\Api\Data\RequestInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;

/**
 * Class ProcessRequest
 * @package Oneglobal\OgCheckout\Model
 */
class ProcessRequest
{
    /**
     * @var OgpayConfig
     */
    protected $ogpayConfig;

    /**
     * @var RequestInterface
     */
    protected $requestInterface;

    /**
     * @var TimezoneInterface
     */
    protected $timezone;

    /**
     * @var array
     */
    protected $currency = [];

    /**
     * ProcessRequest constructor.
     * @param \Oneglobal\Ogpay\Model\OgpayConfig $ogpayConfig
     * @param RequestInterface $requestInterface
     * @param TimezoneInterface $timezone
     */
    public function __construct(
        OgpayConfig $ogpayConfig,
        RequestInterface $requestInterface,
        TimezoneInterface $timezone
    ) {
        $this->ogpayConfig = $ogpayConfig;
        $this->requestInterface = $requestInterface;
        $this->timezone = $timezone;
    }

    /**
     * @param $paymentChannel
     * @param $amount
     * @param $order
     */
    protected function setRequestData($paymentChannel, $amount, $order)
    {
        $date = $this->timezone->date();
        $date = $date->format('Y/m/d H:i:s');

        $dateTimeStamp = $this->timezone->scopeTimeStamp();
        $incrementId = $order->getIncrementId();
        $referenceId = $dateTimeStamp . $incrementId;
        $referenceId = substr($referenceId, 0, 15);

        $callbackUrl = $this->ogpayConfig->getCallbackURL() . '/orderid/' . $incrementId;

        if (empty($this->currency)) {
            $this->getCurrency($order, $paymentChannel);
        }

        $this->requestInterface->setMerchantCode($this->ogpayConfig->getMerchantCode());
        $this->requestInterface->setAuthKey($this->ogpayConfig->getAuthenticationKey());
        $this->requestInterface->setSecretKey($this->ogpayConfig->getSecretKey());
        $this->requestInterface->setCurrency($this->currency['currency']);
        $this->requestInterface->setPaymentChannel($paymentChannel);
        $this->requestInterface->setTunnel($this->ogpayConfig->getTunnel());
        $this->requestInterface->setAmount($amount);
        $this->requestInterface->setDoConvert($this->currency['doConvert']);
        $this->requestInterface->setSourceCurrency($this->currency['sourcecurrency']);
        $this->requestInterface->setDescription($order->getIncrementId());
        $this->requestInterface->setReferenceID((int)$referenceId);
        $this->requestInterface->setTimeStamp($date);
        $this->requestInterface->setLanguage($this->ogpayConfig->getLanguage());
        $this->requestInterface->setCallbackURL($callbackUrl);
    }

    /**
     * @param $paymentChannel
     * @param $amount
     * @param $order
     * @return array
     */
    public function prepareRequest($paymentChannel, $amount, $order)
    {
        $this->setRequestData($paymentChannel, $amount, $order);
        $billingAddress = $order->getBillingAddress();
		
		
		$strUserReference = $billingAddress->getTelephone();
		if(strlen($strUserReference) < 8)
		{
			$strUserReference = str_pad($strUserReference, 8,"0", STR_PAD_RIGHT);
		}

        $this->requestInterface->setUserReference((int)$strUserReference);
        return [
            "merchantCode" => $this->requestInterface->getMerchantCode(),
            "authKey"=> $this->requestInterface->getAuthKey(),
            "currency"=> $this->requestInterface->getCurrency(),
            "pc"=> $this->requestInterface->getPaymentChannel(),
            "tunnel"=> $this->requestInterface->getTunnel(),
            "amount"=> $this->requestInterface->getAmount(),
            "doConvert"=> $this->requestInterface->getDoConvert(),
            "sourceCurrency"=> $this->requestInterface->getSourceCurrency(),
            "description"=> $this->requestInterface->getDescription(),
            "referenceID"=> $this->requestInterface->getReferenceID(),
            "timeStamp"=> $this->requestInterface->getTimeStamp(),
            "language"=> $this->requestInterface->getLanguage(),
            "callbackURL"=> $this->requestInterface->getCallbackURL(),
            "userReference"=> $this->requestInterface->getUserReference(),
            "hash"=> $this->computeHash(),
            "billingDetails" => [
                "fName"=> $order->getCustomerFirstname(),
                "lName"=> $order->getCustomerLastname(),
                "mobile"=> $billingAddress->getTelephone(),
                "email"=> $order->getCustomerEmail(),
                "city"=> $billingAddress->getCity(),
                "pincode"=> $billingAddress->getPostcode(),
                "state"=> $billingAddress->getRegion(),
                "address1"=> $billingAddress->getStreetLine(1),
                "address2"=> $billingAddress->getStreetLine(2)
            ]
        ];
    }

    /**
     * @return string
     */
    private function computeHash()
    {
        $_key=  $this->requestInterface->getSecretKey();
        $data = $this->requestInterface->getAmount() .
            $this->requestInterface->getAuthKey() .
            $this->requestInterface->getCurrency() .
            $this->requestInterface->getMerchantCode() .
            $this->requestInterface->getPaymentChannel() .
            $this->requestInterface->getReferenceID() .
            $this->requestInterface->getSourceCurrency() .
            $this->requestInterface->getTimeStamp() .
            $this->requestInterface->getTunnel() .
            $this->requestInterface->getUserReference();

        return $this->getHashValue($data, $_key);
    }

    /**
     * @param $data
     * @param $HashKey
     * @return string
     */
    private function getHashValue($data, $HashKey)
    {
        $computedHash = strtoupper(hash_hmac("sha256", $data, $HashKey));
        return $computedHash;
    }

    /**
     * @return mixed
     */
    public function gatewayUrl()
    {
        return $this->ogpayConfig->gatewayUrl();
    }

    /**
     * @param $order
     * @param $paymentChannel
     */
    protected function getCurrency($order, $paymentChannel)
    {
        $customize = $this->ogpayConfig->isCustomize();

        $this->currency['currency'] = '';
        $this->currency['doConvert'] = 'N';
        $this->currency['sourcecurrency'] = '';
        $sourceCurrency = $order->getStoreCurrencyCode();

        if (!$customize) {
            //logic for Ogpay Payment
            $currency = $this->getCurrencyForOgpay($order, $paymentChannel);

            if ($paymentChannel == 'all') {
                $this->currency['currency'] = $sourceCurrency;
                $this->currency['doConvert'] = 'N';
                $this->currency['sourcecurrency'] = '';
            } else {
                $this->checkDoConvert($currency, $sourceCurrency);
            }

            return;
        }

        //logic for custom ogpay form
        $currency = $this->ogpayConfig->getCurrencyByChannelCode($paymentChannel);
        $this->checkDoConvert($currency, $sourceCurrency);
    }

    /**
     * @param $currency
     * @param $sourceCurrency
     */
    protected function checkDoConvert($currency, $sourceCurrency)
    {
        $this->currency['currency'] = $currency;
        if ($currency == $sourceCurrency) {
            $this->currency['doConvert'] = 'N';
            $this->currency['sourcecurrency'] = '';
        } else {
            $this->currency['doConvert'] = 'Y';
            $this->currency['sourcecurrency'] = $sourceCurrency;
        }
    }

    /**
     * @param $order
     * @param $paymentChannel
     * @return mixed
     */
    protected function getCurrencyForOgpay($order, $paymentChannel)
    {
        if ($paymentChannel == 'all') {
            return $order->getStoreCurrencyCode();
        }

        return $this->ogpayConfig->getPaymentCurrency();
    }
}
