<?php
/**
 * Created by PhpStorm.
 * User: deepak.shinde@wearefmg.net
 * Date: 12/8/20
 * Time: 12:20 PM
 */

namespace Oneglobal\OgCheckout\Model;

use Magento\Checkout\Model\ConfigProviderInterface;
use Oneglobal\OgCheckout\Model\OgpayConfig;
use Magento\Store\Model\StoreManagerInterface;
use Oneglobal\OgCheckout\Model\Config\Source\PaymentFormType;

/**
 * Class OgpayConfigProvider
 * @package Oneglobal\OgCheckout\Model
 */
class OgpayConfigProvider implements ConfigProviderInterface
{
    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Oneglobal\OgCheckout\Model\OgpayConfig
     */
    protected $ogpayConfig;

    /**
     * OgpayConfigProvider constructor.
     * @param \Oneglobal\OgCheckout\Model\OgpayConfig $ogpayConfig
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        OgpayConfig $ogpayConfig,
        StoreManagerInterface $storeManager
    ) {
        $this->ogpayConfig = $ogpayConfig;
        $this->storeManager  = $storeManager;
    }

    /**
     * @return array
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getConfig()
    {
        $storeId = $this->getStoreId();
        $paymentChannel = $this->getPaymentChannel($storeId);

        $paymentConfig = [
            'payment' => [
                'oneglobal_ogcheckout' => [
                    'description'         => $this->ogpayConfig->getDescription('description', $storeId),
                    'payment_channel'     => $paymentChannel,
                    'is_customize'        => $this->ogpayConfig->isCustomize($storeId),
                    'ogpay_channel'       => $this->ogpayConfig->getPaymentMethod($storeId)
                ]
            ]
        ];
        return $paymentConfig;
    }

    /**
     * @param $storeId
     * @return array
     */
    private function getPaymentChannel($storeId)
    {
        $customize = $this->ogpayConfig->isCustomize($storeId);
        $paymentChannel = [];
        if (!$customize) {
            $pc = $this->ogpayConfig->getPaymentMethod($storeId);
            $paymentChannel[$pc] = 'OgCheckout';

            return $paymentChannel;
        }

        $paymentChannel = $this->ogpayConfig->getPaymentMethodForCustomize();

        return $paymentChannel;
    }

    /**
     * @return int
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function getStoreId()
    {
        return $this->storeManager->getStore()->getId();
    }

    /**
     * @return int
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function getWebsiteId()
    {
        return $this->storeManager->getStore()->getWebsiteId();
    }
}
