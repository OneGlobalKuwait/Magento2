<?php
/**
 * Created by PhpStorm.
 * User: deepak.shinde@wearefmg.net
 * Date: 12/8/20
 * Time: 3:04 PM
 */

namespace Oneglobal\OgCheckout\Model;

use Magento\Store\Model\StoreManagerInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Oneglobal\OgCheckout\Model\Config\Source\PaymentFormType;
use Oneglobal\OgCheckout\Model\ItemsFactory;
use Oneglobal\OgCheckout\Model\Config\Source\PaymentType;

/**
 * Class OgpayConfig
 * @package Oneglobal\OgCheckout\Model
 */
class OgpayConfig
{
    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * Payment method
     *
     * @var string
     */
    private $code = '';

    /**
     * @var ItemsFactory
     */
    protected $itemsFactory;

    /**
     * OgpayConfig constructor.
     * @param StoreManagerInterface $storeManager
     * @param ScopeConfigInterface $scopeConfig
     * @param ItemsFactory $itemsFactory
     */
    public function __construct(
        StoreManagerInterface $storeManager,
        ScopeConfigInterface $scopeConfig,
        ItemsFactory $itemsFactory
    ) {
        $this->storeManager  = $storeManager;
        $this->scopeConfig = $scopeConfig;
        $this->itemsFactory = $itemsFactory;
        $this->code = 'oneglobal_ogcheckout';
    }

    /**
     * @param $field
     * @param null $storeId
     * @return mixed
     */
    public function getConfigValue($field, $storeId = null)
    {
        if (!$storeId) {
            $storeId = $this->getStoreId();
        }

        return $this->scopeConfig->getValue(
            sprintf('payment/' . $this->code . '/%s', $field),
            ScopeInterface::SCOPE_STORE,
            $storeId
        );
    }

    /**
     * @param $field
     * @param null $storeId
     * @return mixed
     */
    public function getDescription($field, $storeId = null)
    {
        return $this->getConfigValue($field, $storeId);
    }

    /**
     * @return array
     */
    public function getPaymentMethodForCustomize()
    {
        $ogpayPayment = $this->itemsFactory->create();
        $collection = $ogpayPayment->getCollection();
        $paymentChannel = [];
        foreach ($collection as $item) {
            $paymentChannel[$item->getChannelCode()] = $item->getTitle();
        }

        return $paymentChannel;
    }

    /**
     * @param $channelCode
     * @return string
     */
    public function getCurrencyByChannelCode($channelCode)
    {
        $ogpayPayment = $this->itemsFactory->create();
        $ogpayPayment->load($channelCode, 'channel_code');

        $currencyCode = '';
        if ($ogpayPayment->getId()) {
            $currencyCode = $ogpayPayment->getCurrencyCode();
        }

        return $currencyCode;
    }

    /**
     * @param null $storeId
     * @return mixed
     */
    public function getMerchantCode($storeId = null)
    {
        return $this->getConfigValue('merchant_code', $storeId);
    }

    public function getAuthenticationKey($storeId = null)
    {
        return $this->getConfigValue('authentication_key', $storeId);
    }

    public function getSecretKey($storeId = null)
    {
        return $this->getConfigValue('secret_key', $storeId);
    }

    public function getPaymentType($storeId = null)
    {
        return $this->getConfigValue('payment_type', $storeId);
    }

    public function getPaymentFormType($storeId = null)
    {
        return $this->getConfigValue('payment_form_type', $storeId);
    }

    public function getAllowspecific($storeId = null)
    {
        return $this->getConfigValue('allowspecific', $storeId);
    }

    public function getPaymentMethod($storeId = null)
    {
        return $this->getConfigValue('payment_method', $storeId);
    }

    public function getPaymentCurrency($storeId = null)
    {
        return $this->getConfigValue('payment_currency', $storeId);
    }

    public function getLanguage($storeId = null)
    {
        return $this->getConfigValue('language', $storeId);
    }

    public function getTunnel($storeId = null)
    {
        return $this->getConfigValue('tunnel', $storeId);
    }

    public function getCallbackURL()
    {
        return $this->getBaseUrl() . 'ogcheckout/success/index';
    }

    private function getBaseUrl()
    {
        $storeId = $this->getStoreId();
        return $this->storeManager->getStore($storeId)->getBaseUrl();
    }

    /**
     * @return int
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function getStoreId()
    {
        return $this->storeManager->getStore()->getId();
    }

    public function gatewayUrl($storeId = null)
    {
        return $this->getConfigValue('endpoint_url', $storeId);
    }

    public function isCustomize($storeId = null)
    {
        $paymentFormType = $this->getPaymentFormType($storeId);

        if ($paymentFormType == PaymentFormType::CUSTOMIZE) {
            return true;
        }

        return false;
    }
}
