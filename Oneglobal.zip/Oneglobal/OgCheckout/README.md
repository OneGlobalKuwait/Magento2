# Magento2
Og Checkout makes it easy for your customers to pay online.

Integrating your Magento2 store with Og Checkout services allows you to accept payments on your OpenCart store with simple installation. You can accept payments via Debit & Credit Card, & ATM Cards. The plugin offers seamless integration, allowing the customer to pay on your website with a high secure PCI compliance hosted environment and work across all browsers. and ensures compatibility with the below versions of Magento2.

# Supported Versions
-Compatibility with Open Source Community Edition : 2.0x, 2.1x, 2.2x, 2.3x, 2.4x.

# Extension Setup Guide
Visit https://checkoutdocs.oneglobal.com/plugins-setup-guide/magento-2
